
package parcialrubenbadaracco321;


public interface Programable {
    void programar();
}
